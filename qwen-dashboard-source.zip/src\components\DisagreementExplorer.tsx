"use client";

import { useEffect, useMemo, useState } from "react";

type Dataset = "train" | "validation" | "test";
type Category = "SL_AVOIDED" | "TP_MISSED" | "TP_ADDED" | "SL_ADDED" | "UNDETERMINED";
type DisagreementRow = {
  time: number;
  timestamp: string;
  available_at: string | null;
  qwen: string;
  heuristic: string;
  target: string;
  bias_score: number;
  qwen_result: string;
  heuristic_result: string;
  type: string;
  category: Category;
  features: {
    close: number | null;
    rsi14: number | null;
    atr14_pct: number | null;
    volume_ratio: number | null;
    trend_1h: number | null;
    trend_4h: number | null;
    trend_1d: number | null;
    trend_alignment: number | null;
    features_ready: boolean | null;
  };
};
type ResponseData = {
  dataset: string;
  count: number;
  missing_market_rows: number;
  counts: {
    qwen_abstains: number;
    qwen_adds_trade: number;
    opposite_direction: number;
    by_category: Record<Category, number>;
  };
  rows: DisagreementRow[];
};
const FILTERS: { value: Category | "ALL"; label: string }[] = [
  { value: "ALL", label: "Tous" },
  { value: "SL_AVOIDED", label: "SL évités" },
  { value: "TP_MISSED", label: "TP manqués" },
  { value: "TP_ADDED", label: "TP ajoutés" },
  { value: "SL_ADDED", label: "SL ajoutés" },
  { value: "UNDETERMINED", label: "Indéterminés" },
];
const LABELS: Record<Category, string> = {
  SL_AVOIDED: "SL évité",
  TP_MISSED: "TP manqué",
  TP_ADDED: "TP ajouté",
  SL_ADDED: "SL ajouté",
  UNDETERMINED: "Indéterminé",
};
function fmt(value: number | null): string {
  return value === null || !Number.isFinite(value) ? "—" : value.toLocaleString("fr-FR", { maximumFractionDigits: 2 });
}
function dt(value: string): string {
  return new Date(value).toISOString().replace("T", " ").slice(0, 16) + " UTC";
}
function decisionColor(value: string) {
  return value === "LONG_BIAS" ? "text-emerald-400" : value === "SHORT_BIAS" ? "text-red-400" : "text-slate-400";
}
function categoryColor(value: Category) {
  return value === "SL_AVOIDED" || value === "TP_ADDED" ? "text-emerald-400" : value === "TP_MISSED" || value === "SL_ADDED" ? "text-red-400" : "text-slate-400";
}
export default function DisagreementExplorer({ dataset, selectedTime, onSelect }: {
  dataset: Dataset;
  selectedTime: number | null;
  onSelect: (time: number) => void;
}) {
  const [data, setData] = useState<ResponseData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [filter, setFilter] = useState<Category | "ALL">("ALL");
  const [search, setSearch] = useState("");

  useEffect(() => {
    const controller = new AbortController();
    if (dataset === "train") return () => controller.abort();
    async function load() {
      setLoading(true); setError(null);
      try {
        const response = await fetch(`http://127.0.0.1:8000/api/analytics/disagreements?dataset=${dataset}`, { signal: controller.signal });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const result: ResponseData = await response.json();
        if (!controller.signal.aborted) setData(result);
      } catch (err) {
        if (!controller.signal.aborted) setError(err instanceof Error ? err.message : String(err));
      } finally {
        if (!controller.signal.aborted) setLoading(false);
      }
    }
    void load();
    return () => controller.abort();
  }, [dataset]);

  const activeData = data?.dataset === dataset ? data : null;
  const rows = useMemo(() => {
    if (!activeData) return [];
    const query = search.trim().toLowerCase();
    return activeData.rows.filter((row) => {
      if (filter !== "ALL" && row.category !== filter) return false;
      return !query || [row.timestamp, row.qwen, row.heuristic, row.target, row.category].join(" ").toLowerCase().includes(query);
    });
  }, [activeData, filter, search]);

  return <section id="disagreements" className="mt-5 rounded-xl border border-slate-800 bg-[#0b1220] p-5 text-slate-100">
    <div className="mb-5 flex flex-wrap items-center justify-between gap-3"><div><h2 className="text-lg font-semibold">Disagreement Explorer</h2><p className="mt-1 text-xs text-slate-400">Comparer les décisions Qwen V2 et heuristique, puis retrouver leur bougie.</p></div><span className="rounded border border-slate-700 px-3 py-1.5 text-xs">{dataset.toUpperCase()}</span></div>
    {dataset === "train" ? <p className="text-sm text-slate-400">Aucun résultat Qwen V2 d'évaluation disponible sur Train.</p>
      : loading || !activeData ? error ? <p className="text-sm text-red-400">{error}</p> : <p className="py-6 text-sm text-slate-400">Chargement des désaccords...</p>
      : <div className="space-y-5">
        <div className="grid gap-3 sm:grid-cols-3">
          {[
            { label: "Désaccords", count: activeData.count },
            { label: "Qwen s'abstient", count: activeData.counts.qwen_abstains },
            { label: "Qwen ajoute un trade", count: activeData.counts.qwen_adds_trade },
          ].map(({ label, count }) => <div key={label} className="rounded-lg border border-slate-800 bg-[#0e1829] p-4"><p className="text-xs text-slate-400">{label}</p><p className="mt-2 text-2xl font-semibold">{count.toLocaleString("fr-FR")}</p></div>)}
        </div>
        {activeData.missing_market_rows > 0 && <p className="rounded border border-amber-800 p-3 text-xs text-amber-300">Attention : {activeData.missing_market_rows} prédictions sans bougie correspondante.</p>}
        <div className="flex flex-wrap gap-2">{FILTERS.map((option) => <button key={option.value} type="button" onClick={() => setFilter(option.value)} className={`rounded-md border px-3 py-2 text-xs transition ${filter === option.value ? "border-blue-500 bg-blue-600 text-white" : "border-slate-700 text-slate-400 hover:bg-slate-800"}`}>{option.label}{option.value !== "ALL" ? ` (${activeData.counts.by_category[option.value]})` : ""}</button>)}</div>
        <input type="search" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Rechercher une date, décision ou catégorie..." className="w-full rounded-lg border border-slate-700 bg-slate-900 px-4 py-2.5 text-sm text-slate-100 outline-none focus:border-blue-500" />
        <p className="text-xs text-slate-400">{rows.length} désaccords affichés · Clique sur une ligne pour naviguer vers la bougie.</p>
        <div className="max-h-[580px] overflow-auto rounded-lg border border-slate-800">
          <table className="w-full min-w-[950px] text-left text-xs">
            <thead className="sticky top-0 z-10 bg-[#172238] text-slate-300"><tr>{["Date UTC", "Qwen", "Heuristique", "Résultat", "RSI14", "ATR %", "Volume ratio", "Bias"].map((title) => <th key={title} className="p-3">{title}</th>)}</tr></thead>
            <tbody>{rows.map((row) => <tr key={row.time} onClick={() => onSelect(row.time)} aria-selected={selectedTime === row.time} className={`cursor-pointer border-t border-slate-800 hover:bg-slate-800 ${selectedTime === row.time ? "bg-amber-900/20" : ""}`}>
              <td className="whitespace-nowrap p-3 font-mono">{dt(row.timestamp)}</td><td className={`p-3 ${decisionColor(row.qwen)}`}>{row.qwen}</td><td className={`p-3 ${decisionColor(row.heuristic)}`}>{row.heuristic}</td><td className={`p-3 font-semibold ${categoryColor(row.category)}`}>{LABELS[row.category]}</td><td className="p-3 text-right font-mono">{fmt(row.features.rsi14)}</td><td className="p-3 text-right font-mono">{fmt(row.features.atr14_pct)}</td><td className="p-3 text-right font-mono">{fmt(row.features.volume_ratio)}</td><td className="p-3 text-right font-mono">{row.bias_score}</td>
            </tr>)}</tbody>
          </table>
          {rows.length === 0 && <p className="p-6 text-center text-sm text-slate-400">Aucun désaccord ne correspond aux filtres.</p>}
        </div>
        <p className="text-xs text-slate-500">Features connues à la clôture. TP/SL calculés a posteriori sur 12H. Aucun trade n'a été exécuté.</p>
      </div>}
  </section>;
}
