
"use client";

import { useEffect, useState } from "react";

type Dataset = "train" | "validation" | "test";

type TradeStats = {
  samples: number;
  long: number;
  short: number;
  no_trade: number;
  directional_signals: number;
  tp: number;
  sl: number;
  unresolved: number;
  unknown: number;
  resolved: number;
  coverage_pct: number | null;
  win_rate_pct: number | null;
  total_r: number;
  expected_r: number | null;
};

type Summary = {
  dataset: string;
  samples: number;
  parameters: {
    tp_atr: number;
    sl_atr: number;
    horizon_hours: number;
    tp_r: number;
    sl_r: number;
    expected_r_denominator: string;
  };
  qwen: TradeStats;
  heuristic: TradeStats;
  agreement: {
    samples: number;
    agreements: number;
    disagreements: number;
    agreement_pct: number | null;
  };
  disagreements: {
    samples: number;
    qwen: TradeStats;
    heuristic: TradeStats;
    qwen_trade_heuristic_abstains: number;
    heuristic_trade_qwen_abstains: number;
    both_trade_different_direction: number;
    qwen_tp_other_not_tp: number;
    heuristic_tp_other_not_tp: number;
    both_tp: number;
    both_sl: number;
  };
  by_direction: {
    qwen: {
      long: TradeStats;
      short: TradeStats;
    };
    heuristic: {
      long: TradeStats;
      short: TradeStats;
    };
  };
  disclaimer: string;
};

type View = "overview" | "directions" | "disagreements";

function fmt(value: number | null, digits = 2): string {
  if (value === null || !Number.isFinite(value)) {
    return "—";
  }
  return value.toLocaleString("fr-FR", {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  });
}

function signed(value: number | null, digits = 4): string {
  if (value === null) return "—";
  return `${value > 0 ? "+" : ""}${fmt(value, digits)}`;
}

function valueColor(value: number | null): string {
  if (value === null) return "text-slate-400";
  if (value > 0) return "text-emerald-400";
  if (value < 0) return "text-red-400";
  return "text-slate-200";
}

function Metric({
  title,
  value,
  detail,
  tone,
}: {
  title: string;
  value: string;
  detail?: string;
  tone?: string;
}) {
  return (
    <div className="rounded-lg border border-slate-800 bg-[#0e1829] p-4">
      <p className="text-xs text-slate-400">{title}</p>
      <p className={`mt-2 text-2xl font-semibold ${tone ?? "text-white"}`}>
        {value}
      </p>
      {detail && (
        <p className="mt-2 text-xs text-slate-500">{detail}</p>
      )}
    </div>
  );
}

function ResultTable({
  qwen,
  heuristic,
}: {
  qwen: TradeStats;
  heuristic: TradeStats;
}) {
  const rows: {
    label: string;
    qwen: string;
    heuristic: string;
  }[] = [
    {
      label: "LONG",
      qwen: fmt(qwen.long, 0),
      heuristic: fmt(heuristic.long, 0),
    },
    {
      label: "SHORT",
      qwen: fmt(qwen.short, 0),
      heuristic: fmt(heuristic.short, 0),
    },
    {
      label: "NO_TRADE",
      qwen: fmt(qwen.no_trade, 0),
      heuristic: fmt(heuristic.no_trade, 0),
    },
    {
      label: "Signaux directionnels",
      qwen: fmt(qwen.directional_signals, 0),
      heuristic: fmt(heuristic.directional_signals, 0),
    },
    {
      label: "TP",
      qwen: fmt(qwen.tp, 0),
      heuristic: fmt(heuristic.tp, 0),
    },
    {
      label: "SL",
      qwen: fmt(qwen.sl, 0),
      heuristic: fmt(heuristic.sl, 0),
    },
    {
      label: "Non résolus",
      qwen: fmt(qwen.unresolved, 0),
      heuristic: fmt(heuristic.unresolved, 0),
    },
    {
      label: "Inconnus",
      qwen: fmt(qwen.unknown, 0),
      heuristic: fmt(heuristic.unknown, 0),
    },
    {
      label: "Win rate résolus",
      qwen: `${fmt(qwen.win_rate_pct)} %`,
      heuristic: `${fmt(heuristic.win_rate_pct)} %`,
    },
    {
      label: "Coverage",
      qwen: `${fmt(qwen.coverage_pct)} %`,
      heuristic: `${fmt(heuristic.coverage_pct)} %`,
    },
    {
      label: "Expected R",
      qwen: signed(qwen.expected_r),
      heuristic: signed(heuristic.expected_r),
    },
    {
      label: "Total R",
      qwen: signed(qwen.total_r, 2),
      heuristic: signed(heuristic.total_r, 2),
    },
  ];

  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[520px] text-left text-sm">
        <thead>
          <tr className="border-b border-slate-700 text-slate-400">
            <th className="py-3 font-medium">Métrique</th>
            <th className="py-3 text-right font-medium">Qwen V2</th>
            <th className="py-3 text-right font-medium">Heuristique</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr
              key={row.label}
              className="border-b border-slate-800/70"
            >
              <td className="py-2.5 text-slate-300">
                {row.label}
              </td>
              <td className="py-2.5 text-right font-mono text-slate-100">
                {row.qwen}
              </td>
              <td className="py-2.5 text-right font-mono text-slate-100">
                {row.heuristic}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function RateBar({
  label,
  value,
  detail,
}: {
  label: string;
  value: number | null;
  detail?: string;
}) {
  const percentage = Math.max(
    0,
    Math.min(100, value ?? 0)
  );

  return (
    <div className="space-y-2">
      <div className="flex justify-between gap-3 text-xs">
        <span className="text-slate-300">{label}</span>
        <span className="font-mono text-slate-100">
          {fmt(value)} %
        </span>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-slate-800">
        <div
          className="h-full rounded-full bg-blue-500"
          style={{ width: `${percentage}%` }}
        />
      </div>
      {detail && (
        <p className="text-xs text-slate-500">{detail}</p>
      )}
    </div>
  );
}

function DirectionCard({
  title,
  stats,
}: {
  title: string;
  stats: TradeStats;
}) {
  return (
    <div className="rounded-lg border border-slate-800 bg-[#0e1829] p-4">
      <h4 className="mb-4 font-semibold">{title}</h4>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <p className="text-xs text-slate-400">Signaux</p>
          <p className="mt-1 text-xl font-semibold">
            {fmt(stats.directional_signals, 0)}
          </p>
        </div>
        <div>
          <p className="text-xs text-slate-400">Win rate</p>
          <p className="mt-1 text-xl font-semibold">
            {fmt(stats.win_rate_pct)} %
          </p>
        </div>
        <div>
          <p className="text-xs text-slate-400">TP / SL</p>
          <p className="mt-1 text-sm font-mono">
            <span className="text-emerald-400">{stats.tp}</span>
            {" / "}
            <span className="text-red-400">{stats.sl}</span>
          </p>
        </div>
        <div>
          <p className="text-xs text-slate-400">Expected R</p>
          <p className={`mt-1 text-lg font-semibold ${valueColor(stats.expected_r)}`}>
            {signed(stats.expected_r)} R
          </p>
        </div>
      </div>
      <p className="mt-4 text-xs text-slate-500">
        {stats.unresolved} non résolus · {stats.unknown} inconnus
      </p>
    </div>
  );
}

export default function PerformanceAnalytics({
  dataset,
}: {
  dataset: Dataset;
}) {
  const [summary, setSummary] = useState<Summary | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [view, setView] = useState<View>("overview");

  useEffect(() => {
    const controller = new AbortController();

    if (dataset === "train") {
      return () => controller.abort();
    }

    async function load() {
      setLoading(true);
      setError(null);

      try {
        const response = await fetch(
          `http://127.0.0.1:8000/api/analytics/summary?dataset=${dataset}`,
          { signal: controller.signal }
        );

        if (!response.ok) {
          throw new Error(`HTTP ${response.status}`);
        }

        const data: Summary = await response.json();

        if (!controller.signal.aborted) {
          setSummary(data);
        }
      } catch (err) {
        if (!controller.signal.aborted) {
          setError(
            err instanceof Error ? err.message : String(err)
          );
        }
      } finally {
        if (!controller.signal.aborted) {
          setLoading(false);
        }
      }
    }

    void load();

    return () => controller.abort();
  }, [dataset]);

  const activeSummary =
    summary?.dataset === dataset ? summary : null;

  return (
    <section className="mt-5 rounded-xl border border-slate-800 bg-[#0b1220] p-5 text-slate-100">
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold">
            Performance Analytics
          </h2>
          <p className="mt-1 text-xs text-slate-400">
            Analyse globale des prédictions historiques
          </p>
        </div>
        <span className="rounded border border-slate-700 px-3 py-1.5 text-xs text-slate-300">
          {dataset.toUpperCase()}
        </span>
      </div>

      {dataset === "train" ? (
        <p className="rounded-lg border border-slate-800 p-5 text-sm text-slate-400">
          Aucune évaluation Qwen V2 disponible sur Train.
          Sélectionne Validation ou Test.
        </p>
      ) : loading || !activeSummary ? (
        error ? (
          <p className="text-sm text-red-400">
            Impossible de charger les statistiques : {error}
          </p>
        ) : (
          <p className="py-8 text-sm text-slate-400">
            Chargement des statistiques...
          </p>
        )
      ) : (
        <>
          <div className="mb-5 flex flex-wrap gap-2">
            {([
              ["overview", "Vue globale"],
              ["directions", "LONG vs SHORT"],
              ["disagreements", "Désaccords"],
            ] as const).map(([id, label]) => (
              <button
                key={id}
                type="button"
                onClick={() => setView(id)}
                className={[
                  "rounded-md px-4 py-2 text-sm transition",
                  view === id
                    ? "bg-blue-600 font-medium text-white"
                    : "bg-slate-900 text-slate-400 hover:bg-slate-800",
                ].join(" ")}
              >
                {label}
              </button>
            ))}
          </div>

          {view === "overview" && (
            <div className="space-y-6">
              <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
                <Metric
                  title="Qwen · Expected R"
                  value={`${signed(activeSummary.qwen.expected_r)} R`}
                  detail={`${activeSummary.qwen.resolved} trades résolus`}
                  tone={valueColor(activeSummary.qwen.expected_r)}
                />
                <Metric
                  title="Heuristique · Expected R"
                  value={`${signed(activeSummary.heuristic.expected_r)} R`}
                  detail={`${activeSummary.heuristic.resolved} trades résolus`}
                  tone={valueColor(activeSummary.heuristic.expected_r)}
                />
                <Metric
                  title="Accord Qwen / Heuristique"
                  value={`${fmt(activeSummary.agreement.agreement_pct)} %`}
                  detail={`${activeSummary.agreement.disagreements} désaccords`}
                />
                <Metric
                  title="Observations"
                  value={fmt(activeSummary.samples, 0)}
                  detail="Dataset complet"
                />
              </div>

              <div className="grid gap-5 lg:grid-cols-2">
                <div className="rounded-lg border border-slate-800 p-4">
                  <h3 className="mb-4 font-semibold">
                    Win rate des trades résolus
                  </h3>
                  <div className="space-y-5">
                    <RateBar
                      label="Qwen V2"
                      value={activeSummary.qwen.win_rate_pct}
                      detail={`${activeSummary.qwen.tp} TP / ${activeSummary.qwen.sl} SL`}
                    />
                    <RateBar
                      label="Heuristique"
                      value={activeSummary.heuristic.win_rate_pct}
                      detail={`${activeSummary.heuristic.tp} TP / ${activeSummary.heuristic.sl} SL`}
                    />
                  </div>
                </div>

                <div className="rounded-lg border border-slate-800 p-4">
                  <h3 className="mb-4 font-semibold">
                    Participation au marché
                  </h3>
                  <div className="space-y-5">
                    <RateBar
                      label="Qwen V2"
                      value={activeSummary.qwen.coverage_pct}
                      detail={`${activeSummary.qwen.directional_signals} signaux directionnels`}
                    />
                    <RateBar
                      label="Heuristique"
                      value={activeSummary.heuristic.coverage_pct}
                      detail={`${activeSummary.heuristic.directional_signals} signaux directionnels`}
                    />
                  </div>
                </div>
              </div>

              <ResultTable
                qwen={activeSummary.qwen}
                heuristic={activeSummary.heuristic}
              />
            </div>
          )}

          {view === "directions" && (
            <div className="grid gap-4 md:grid-cols-2">
              <DirectionCard
                title="Qwen · LONG"
                stats={activeSummary.by_direction.qwen.long}
              />
              <DirectionCard
                title="Qwen · SHORT"
                stats={activeSummary.by_direction.qwen.short}
              />
              <DirectionCard
                title="Heuristique · LONG"
                stats={activeSummary.by_direction.heuristic.long}
              />
              <DirectionCard
                title="Heuristique · SHORT"
                stats={activeSummary.by_direction.heuristic.short}
              />
            </div>
          )}

          {view === "disagreements" && (
            <div className="space-y-5">
              <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
                <Metric
                  title="Désaccords"
                  value={fmt(activeSummary.disagreements.samples, 0)}
                  detail="Décisions différentes"
                />
                <Metric
                  title="Qwen trade seul"
                  value={fmt(
                    activeSummary.disagreements.qwen_trade_heuristic_abstains,
                    0
                  )}
                  detail="Heuristique = NO_TRADE"
                />
                <Metric
                  title="Heuristique trade seule"
                  value={fmt(
                    activeSummary.disagreements.heuristic_trade_qwen_abstains,
                    0
                  )}
                  detail="Qwen = NO_TRADE"
                />
                <Metric
                  title="Directions opposées"
                  value={fmt(
                    activeSummary.disagreements.both_trade_different_direction,
                    0
                  )}
                  detail="Deux trades directionnels différents"
                />
              </div>

              <ResultTable
                qwen={activeSummary.disagreements.qwen}
                heuristic={activeSummary.disagreements.heuristic}
              />

              <div className="rounded-lg border border-slate-800 p-4">
                <h3 className="mb-3 font-semibold">
                  Issues des désaccords
                </h3>
                <div className="space-y-2 text-sm">
                  {[
                    [
                      "Qwen TP, heuristique non TP",
                      activeSummary.disagreements.qwen_tp_other_not_tp,
                    ],
                    [
                      "Heuristique TP, Qwen non TP",
                      activeSummary.disagreements.heuristic_tp_other_not_tp,
                    ],
                    [
                      "Les deux TP",
                      activeSummary.disagreements.both_tp,
                    ],
                    [
                      "Les deux SL",
                      activeSummary.disagreements.both_sl,
                    ],
                  ].map(([label, value]) => (
                    <div
                      key={String(label)}
                      className="flex justify-between border-b border-slate-800 py-2"
                    >
                      <span className="text-slate-400">
                        {label}
                      </span>
                      <span className="font-mono font-medium">
                        {value}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <p className="text-xs text-slate-500">
                Une abstention n'est jamais comptée comme
                un trade gagnant. Les catégories sont
                basées sur les outcomes 12H.
              </p>
            </div>
          )}

          <p className="mt-6 border-t border-slate-800 pt-4 text-xs text-slate-500">
            TP = +{activeSummary.parameters.tp_r} R · SL ={" "}
            {activeSummary.parameters.sl_r} R · Horizon{" "}
            {activeSummary.parameters.horizon_hours}H.
            Expected R calculé uniquement sur les trades
            résolus. Les signaux peuvent se chevaucher :
            il ne s'agit pas d'un backtest exécutable.
          </p>
        </>
      )}
    </section>
  );
}
