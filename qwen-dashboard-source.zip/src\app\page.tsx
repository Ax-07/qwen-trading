"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { toBlob } from "html-to-image";
import TradingChart, {
  type Candle,
  type SignalFilter,
  type SignalSettings,
  type TradingSignal,
} from "@/components/TradingChart";
import PerformanceAnalytics from "@/components/PerformanceAnalytics";
import DisagreementExplorer from "@/components/DisagreementExplorer";

const API = "http://127.0.0.1:8000";
type Dataset = "train" | "validation" | "test";
type FeatureValue = number | boolean | null;
type DatasetInfo = {
  name: Dataset;
  available: boolean;
  start: string | null;
  end: string | null;
  rows: number | null;
  message: string | null;
};
type CandleDetail = {
  time: number;
  timestamp: string;
  available_at: string;
  features: Record<string, FeatureValue>;
};
type PredictionDetail = {
  available: boolean;
  message?: string;
  predictions?: { qwen: string; heuristic: string; generated: string; bias_score: number };
  evaluation?: {
    target: string;
    decision: string;
    long_result: string;
    short_result: string;
    future_return_12h_pct: number | null;
    up_move_12h_atr: number | null;
    down_move_12h_atr: number | null;
  };
  comparison?: {
    qwen_agrees_with_heuristic: boolean;
    qwen_matches_target: boolean;
    heuristic_matches_target: boolean;
  };
};

const GROUPS = [
  { title: "OHLCV", fields: ["open", "high", "low", "close", "volume"] },
  {
    title: "Indicateurs 1H",
    fields: ["ema20", "ema50", "ema200", "rsi14", "atr14", "atr14_pct", "volume_ratio", "trend_1h"],
  },
  { title: "Tendance 4H", fields: ["4h_close", "4h_ema20", "4h_ema50", "4h_rsi14", "4h_atr14_pct", "4h_trend"] },
  {
    title: "Tendance 1D",
    fields: ["1d_close", "1d_ema20", "1d_ema50", "1d_rsi14", "1d_atr14_pct", "1d_trend", "trend_alignment"],
  },
  {
    title: "Returns & Volatilité",
    fields: ["return_1h", "return_3h", "return_6h", "return_24h", "log_return_1h", "volatility_24h", "volatility_72h"],
  },
  {
    title: "Breakouts & Structure",
    fields: [
      "prev_high_24h",
      "prev_low_24h",
      "prev_high_72h",
      "prev_low_72h",
      "breakout_24h",
      "breakdown_24h",
      "distance_high_24h_pct",
      "distance_low_24h_pct",
      "distance_high_72h_pct",
      "distance_low_72h_pct",
    ],
  },
  {
    title: "Autres features",
    fields: [
      "distance_ema20_pct",
      "distance_ema50_pct",
      "distance_ema200_pct",
      "ema20_50_spread_pct",
      "ema50_200_spread_pct",
      "volume_sma20",
      "range_pct",
      "body_pct",
      "upper_wick_pct",
      "lower_wick_pct",
    ],
  },
];

function num(value: FeatureValue | undefined, digits = 4): string {
  if (value == null) return "—";
  if (typeof value === "boolean") return value ? "Oui" : "Non";
  if (!Number.isFinite(value)) return "—";
  return value.toLocaleString("fr-FR", { maximumFractionDigits: digits });
}
function utc(value: string | null | undefined): string {
  if (!value) return "—";
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? "—" : d.toISOString().replace("T", " ").slice(0, 16) + " UTC";
}
function Badge({ value }: { value: string | undefined }) {
  const theme =
    value === "LONG_BIAS" || value === "TP"
      ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-300"
      : value === "SHORT_BIAS" || value === "SL"
        ? "border-rose-500/40 bg-rose-500/10 text-rose-300"
        : "border-slate-600/60 bg-slate-700/30 text-slate-300";
  return (
    <span className={`inline-flex rounded-md border px-2 py-1 text-[11px] font-semibold ${theme}`}>{value ?? "—"}</span>
  );
}
function Line({ label, value, valueClass = "" }: { label: string; value: React.ReactNode; valueClass?: string }) {
  return (
    <div className="flex items-center justify-between gap-3 border-b border-white/[0.045] py-2 text-xs last:border-0">
      <span className="text-slate-400">{label}</span>
      <span className={`text-right font-medium tabular-nums text-slate-100 ${valueClass}`}>{value}</span>
    </div>
  );
}
function Panel({
  title,
  subtitle,
  children,
  action,
}: {
  title: string;
  subtitle: string;
  children: React.ReactNode;
  action?: React.ReactNode;
}) {
  return (
    <section className="rounded-xl border border-[#24334d] bg-[#0c1729] shadow-[0_8px_30px_rgba(0,0,0,.13)]">
      <div className="flex items-start justify-between gap-3 border-b border-[#24334d] px-4 py-4">
        <div>
          <h2 className="text-sm font-semibold tracking-tight text-slate-100">{title}</h2>
          <p className="mt-1 text-[11px] text-slate-500">{subtitle}</p>
        </div>
        {action}
      </div>
      <div className="p-4">{children}</div>
    </section>
  );
}
function AIInspector({
  dataset,
  selectedTime,
  detail,
  loading,
  error,
}: {
  dataset: Dataset;
  selectedTime: number | null;
  detail: PredictionDetail | null;
  loading: boolean;
  error: string | null;
}) {
  const p = detail?.predictions,
    e = detail?.evaluation,
    c = detail?.comparison;
  return (
    <Panel
      title="AI Inspector"
      subtitle="Décisions historiques · Qwen V2 vs heuristique"
      action={<span className="rounded-md bg-blue-500/10 px-2 py-1 text-[10px] text-blue-300">V2</span>}
    >
      {selectedTime === null ? (
        <p className="py-9 text-center text-xs text-slate-500">Sélectionne une bougie sur le graphique.</p>
      ) : dataset === "train" ? (
        <p className="text-xs text-slate-400">Pas d’évaluation Qwen V2 disponible pour Train.</p>
      ) : loading ? (
        <p className="py-5 text-xs text-slate-400">Chargement des prédictions…</p>
      ) : error ? (
        <p className="text-xs text-red-400">{error}</p>
      ) : !detail?.available || !p || !e || !c ? (
        <p className="text-xs text-slate-400">{detail?.message ?? "Prédiction indisponible"}</p>
      ) : (
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-2">
            <div className="rounded-lg border border-[#263753] bg-[#112039] p-3">
              <p className="mb-2 text-[11px] text-slate-400">Qwen V2</p>
              <Badge value={p.qwen} />
            </div>
            <div className="rounded-lg border border-[#263753] bg-[#112039] p-3">
              <p className="mb-2 text-[11px] text-slate-400">Heuristique</p>
              <Badge value={p.heuristic} />
            </div>
          </div>
          <div className="rounded-lg border border-[#263753] bg-[#101e35] px-3 py-1">
            <Line
              label="Accord entre modèles"
              value={c.qwen_agrees_with_heuristic ? "Oui" : "Non"}
              valueClass={c.qwen_agrees_with_heuristic ? "!text-emerald-400" : "!text-amber-300"}
            />
            <Line label="Bias score" value={num(p.bias_score, 2)} />
          </div>
          <div>
            <h3 className="mb-2 text-[10px] font-semibold uppercase tracking-wider text-amber-300">
              Évaluation a posteriori
            </h3>
            <Line label="Target" value={<Badge value={e.target} />} />
            <Line label="Qwen = target" value={c.qwen_matches_target ? "Oui" : "Non"} />
            <Line label="Heuristique = target" value={c.heuristic_matches_target ? "Oui" : "Non"} />
          </div>
          <div>
            <p className="mb-2 text-xs font-semibold text-slate-200">Outcomes futurs · 12H</p>
            <div className="grid grid-cols-2 gap-2">
              <div className="rounded-lg border border-[#29364e] p-3">
                <div className="mb-2 text-[11px] text-slate-500">LONG</div>
                <Badge value={e.long_result} />
              </div>
              <div className="rounded-lg border border-[#29364e] p-3">
                <div className="mb-2 text-[11px] text-slate-500">SHORT</div>
                <Badge value={e.short_result} />
              </div>
            </div>
            <div className="mt-2">
              <Line label="Future return 12H" value={`${num(e.future_return_12h_pct, 4)} %`} />
              <Line label="Up move (ATR)" value={num(e.up_move_12h_atr)} />
              <Line label="Down move (ATR)" value={num(e.down_move_12h_atr)} />
            </div>
          </div>
          <details className="rounded-lg border border-[#29364e] p-3">
            <summary className="cursor-pointer text-xs text-slate-300">Réponse brute Qwen</summary>
            <pre className="mt-3 whitespace-pre-wrap break-words text-[11px] text-slate-400">{p.generated}</pre>
          </details>
          <p className="rounded-lg border border-amber-600/25 bg-amber-500/[0.06] p-3 text-[11px] leading-relaxed text-amber-200">
            Les targets et outcomes sont des informations futures utilisées uniquement pour l’évaluation.
          </p>
        </div>
      )}
    </Panel>
  );
}
function CandleInspector({
  detail,
  loading,
  error,
}: {
  detail: CandleDetail | null;
  loading: boolean;
  error: string | null;
}) {
  return (
    <Panel title="Candle Inspector" subtitle="Données connues à la clôture de la bougie">
      {loading ? (
        <p className="py-5 text-xs text-slate-400">Chargement des features…</p>
      ) : error ? (
        <p className="text-xs text-red-400">{error}</p>
      ) : !detail ? (
        <p className="py-7 text-center text-xs text-slate-500">Clique sur une bougie pour afficher ses features.</p>
      ) : (
        <div className="space-y-3">
          <div className="rounded-lg border border-[#273954] bg-[#112039] p-3 text-[11px]">
            <div className="text-slate-500">Début de bougie</div>
            <p className="mt-1 text-slate-100">{utc(detail.timestamp)}</p>
            <div className="mt-3 text-slate-500">Features disponibles à</div>
            <p className="mt-1 text-emerald-300">{utc(detail.available_at)}</p>
            <p className="mt-2 text-slate-400">
              Features prêtes :{" "}
              <span className="font-semibold text-slate-100">{num(detail.features.features_ready)}</span>
            </p>
          </div>
          {GROUPS.map((group, i) => (
            <details
              key={`${detail.time}-${group.title}`}
              open={i < 2}
              className="rounded-lg border border-[#26364f] bg-[#0d1b30] px-3 py-2.5"
            >
              <summary className="cursor-pointer text-xs font-semibold text-slate-200">{group.title}</summary>
              <div className="mt-2">
                {group.fields.map((field) => (
                  <Line key={field} label={field} value={num(detail.features[field], 6)} />
                ))}
              </div>
            </details>
          ))}
          <p className="text-[11px] text-emerald-400">Aucun outcome futur dans ce panneau.</p>
        </div>
      )}
    </Panel>
  );
}
function FilterButton({
  active,
  children,
  onClick,
}: {
  active: boolean;
  children: React.ReactNode;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`rounded-md border px-3 py-1.5 text-xs transition-colors ${active ? "border-blue-500 bg-blue-600 font-medium text-white" : "border-[#30415d] bg-[#111e33] text-slate-400 hover:border-blue-400/50 hover:text-white"}`}
    >
      {children}
    </button>
  );
}

export default function Home() {
  const dashboardRef = useRef<HTMLElement>(null);
  const [dataset, setDataset] = useState<Dataset>("test");
  const [datasets, setDatasets] = useState<DatasetInfo[]>([]);
  const [candles, setCandles] = useState<Candle[]>([]);
  const [signals, setSignals] = useState<TradingSignal[]>([]);
  const [signalSettings, setSignalSettings] = useState<SignalSettings>({
    qwen: true,
    heuristic: false,
    target: false,
    filter: "all",
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [signalError, setSignalError] = useState<string | null>(null);
  const [selectedTime, setSelectedTime] = useState<number | null>(null);
  const [focusedTime, setFocusedTime] = useState<number | null>(null);
  const [detail, setDetail] = useState<CandleDetail | null>(null);
  const [prediction, setPrediction] = useState<PredictionDetail | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [predictionLoading, setPredictionLoading] = useState(false);
  const [detailError, setDetailError] = useState<string | null>(null);
  const [predictionError, setPredictionError] = useState<string | null>(null);
  const [capturing, setCapturing] = useState(false);
  const [captureStatus, setCaptureStatus] = useState("");
  const activeDataset = datasets.find((item) => item.name === dataset);

  useEffect(() => {
    const controller = new AbortController();
    fetch(`${API}/api/datasets`, { signal: controller.signal })
      .then((r) => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        return r.json();
      })
      .then((data: { datasets: DatasetInfo[] }) => {
        if (!controller.signal.aborted) setDatasets(data.datasets);
      })
      .catch((err) => {
        if (!controller.signal.aborted) console.error("Datasets :", err);
      });
    return () => controller.abort();
  }, []);

  useEffect(() => {
    const controller = new AbortController();
    async function load() {
      setLoading(true);
      setError(null);
      setCandles([]);
      try {
        const params = new URLSearchParams({ dataset, limit: "500" });
        if (focusedTime !== null) {
          const span = 72 * 3600;
          params.set("start", new Date((focusedTime - span) * 1000).toISOString());
          params.set("end", new Date((focusedTime + span) * 1000).toISOString());
        }
        const r = await fetch(`${API}/api/candles?${params}`, { signal: controller.signal });
        if (!r.ok) throw new Error(`Erreur bougies : HTTP ${r.status}`);
        const data: { candles: Candle[] } = await r.json();
        if (!controller.signal.aborted) setCandles(data.candles);
      } catch (err) {
        if (!controller.signal.aborted) setError(String(err));
      } finally {
        if (!controller.signal.aborted) setLoading(false);
      }
    }
    void load();
    return () => controller.abort();
  }, [dataset, focusedTime]);

  useEffect(() => {
    const controller = new AbortController();
    setSignals([]);
    setSignalError(null);
    if (dataset === "train" || candles.length === 0) return () => controller.abort();
    async function load() {
      try {
        const params = new URLSearchParams({
          dataset,
          limit: "2000",
          start: new Date(candles[0].time * 1000).toISOString(),
          end: new Date(candles[candles.length - 1].time * 1000).toISOString(),
        });
        const r = await fetch(`${API}/api/signals?${params}`, { signal: controller.signal });
        if (!r.ok) throw new Error(`Erreur signaux : HTTP ${r.status}`);
        const data: { signals: TradingSignal[] } = await r.json();
        if (!controller.signal.aborted) setSignals(data.signals);
      } catch (err) {
        if (!controller.signal.aborted) setSignalError(String(err));
      }
    }
    void load();
    return () => controller.abort();
  }, [dataset, candles]);

  useEffect(() => {
    const controller = new AbortController();
    if (selectedTime === null) return () => controller.abort();
    setDetail(null);
    setPrediction(null);
    setDetailError(null);
    setPredictionError(null);
    setDetailLoading(true);
    setPredictionLoading(dataset !== "train");
    async function getFeatures() {
      try {
        const r = await fetch(`${API}/api/candles/${selectedTime}`, { signal: controller.signal });
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        const data: CandleDetail = await r.json();
        if (!controller.signal.aborted) setDetail(data);
      } catch (err) {
        if (!controller.signal.aborted) setDetailError(String(err));
      } finally {
        if (!controller.signal.aborted) setDetailLoading(false);
      }
    }
    async function getPrediction() {
      if (dataset === "train") return;
      try {
        const r = await fetch(`${API}/api/predictions/${selectedTime}?dataset=${dataset}`, {
          signal: controller.signal,
        });
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        const data: PredictionDetail = await r.json();
        if (!controller.signal.aborted) setPrediction(data);
      } catch (err) {
        if (!controller.signal.aborted) setPredictionError(String(err));
      } finally {
        if (!controller.signal.aborted) setPredictionLoading(false);
      }
    }
    void getFeatures();
    void getPrediction();
    return () => controller.abort();
  }, [selectedTime, dataset]);

  const changeDataset = useCallback(
    (next: Dataset) => {
      if (next === dataset) return;
      setSelectedTime(null);
      setFocusedTime(null);
      setDetail(null);
      setPrediction(null);
      setSignals([]);
      setDetailError(null);
      setPredictionError(null);
      setDetailLoading(false);
      setPredictionLoading(false);
      setDataset(next);
    },
    [dataset],
  );

  const navigateToDisagreement = useCallback((time: number) => {
    setSelectedTime(time);
    setFocusedTime(time);
    requestAnimationFrame(() =>
      document.getElementById("market-chart")?.scrollIntoView({ behavior: "smooth", block: "start" }),
    );
  }, []);

  async function copyDashboard() {
    if (!dashboardRef.current || capturing) return;
    setCapturing(true);
    setCaptureStatus("Capture en cours…");
    try {
      const pendingBlob = toBlob(dashboardRef.current, {
        backgroundColor: "#070d18",
        pixelRatio: 1.5,
        filter: (node) => !(node instanceof HTMLElement && node.dataset.captureExclude === "true"),
      }).then((blob) => {
        if (!blob) throw new Error("PNG indisponible");
        return blob;
      });
      await navigator.clipboard.write([new ClipboardItem({ "image/png": pendingBlob })]);
      setCaptureStatus("Interface copiée !");
    } catch (err) {
      console.error(err);
      setCaptureStatus("Échec de la copie");
    } finally {
      setCapturing(false);
    }
  }

  const signalCounts = useMemo(() => {
    const valid = new Set(candles.map((c) => c.time));
    let long = 0,
      short = 0,
      tp = 0,
      sl = 0,
      other = 0;
    for (const s of signals) {
      if (!valid.has(s.time) || (signalSettings.filter === "disagree" && !s.disagreement)) continue;
      for (const source of ["qwen", "heuristic", "target"] as const) {
        if (!signalSettings[source]) continue;
        const d = s[source];
        if (d !== "LONG_BIAS" && d !== "SHORT_BIAS") continue;
        const result = s[`${source}_result`];
        if (signalSettings.filter === "win" && result !== "TP") continue;
        if (signalSettings.filter === "loss" && result !== "SL") continue;
        if (d === "LONG_BIAS") long++;
        else short++;
        if (result === "TP") tp++;
        else if (result === "SL") sl++;
        else other++;
      }
    }
    return { long, short, tp, sl, other, total: long + short };
  }, [candles, signals, signalSettings]);

  return (
    <main ref={dashboardRef} className="min-h-screen bg-[#070d18] text-slate-100">
      <header
        className="sticky top-0 z-30 border-b border-[#1c2d47] bg-[#071226]/95 px-4 backdrop-blur-xl xl:px-6"
        data-capture-exclude="false"
      >
        <div className="mx-auto flex min-h-[66px] max-w-[1920px] items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-xl border border-blue-400/30 bg-blue-500/15 text-xl text-blue-300">
              ◈
            </div>
            <div>
              <h1 className="text-base font-bold tracking-tight">Qwen Trading</h1>
              <p className="text-[11px] text-slate-500">AI Market Research Dashboard</p>
            </div>
          </div>
          <nav className="hidden items-center gap-1 lg:flex" aria-label="Navigation">
            <a
              href="#market-chart"
              className="rounded-lg border border-blue-500/30 bg-blue-600/20 px-4 py-2 text-xs font-medium text-blue-200"
            >
              Tableau de bord
            </a>
            <a
              href="#disagreements"
              className="rounded-lg px-4 py-2 text-xs text-slate-400 transition hover:bg-white/5 hover:text-white"
            >
              Exploration
            </a>
            <a
              href="#analytics"
              className="rounded-lg px-4 py-2 text-xs text-slate-400 transition hover:bg-white/5 hover:text-white"
            >
              Analyses
            </a>
          </nav>
          <div className="flex items-center gap-3">
            <span className="hidden items-center gap-2 text-[11px] text-emerald-400 md:inline-flex">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
              Données historiques
            </span>
            <span className="rounded-lg border border-[#2b3b56] bg-[#101e33] px-3 py-2 text-xs">BTC / USDC · 1H</span>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-[1920px] space-y-4 px-3 py-4 sm:px-5 xl:px-6">
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[#24334d] bg-[#0c1729] px-4 py-3">
          <div className="flex flex-wrap items-center gap-4">
            <span className="text-[11px] font-semibold uppercase tracking-widest text-slate-500">Jeu de données</span>
            <div className="flex gap-1 rounded-lg border border-[#273850] bg-[#071224] p-1">
              {(["train", "validation", "test"] as Dataset[]).map((name) => (
                <button
                  key={name}
                  type="button"
                  disabled={datasets.find((d) => d.name === name)?.available === false}
                  onClick={() => changeDataset(name)}
                  className={`rounded-md px-4 py-2 text-xs font-medium transition disabled:cursor-not-allowed disabled:opacity-35 ${dataset === name ? "bg-blue-600 text-white shadow-lg shadow-blue-600/20" : "text-slate-400 hover:bg-white/5 hover:text-white"}`}
                >
                  {name === "train" ? "Train" : name === "validation" ? "Validation" : "Test"}
                </button>
              ))}
            </div>
            <span className="text-[11px] text-slate-400">
              {activeDataset?.start && activeDataset.end
                ? `${utc(activeDataset.start)} → ${utc(activeDataset.end)} · ${activeDataset.rows ?? "—"} lignes`
                : (activeDataset?.message ?? "Chargement des périodes…")}
            </span>
          </div>
          <div className="flex items-center gap-2" data-capture-exclude="true">
            <button
              onClick={copyDashboard}
              disabled={capturing}
              className="rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white transition hover:bg-blue-500 disabled:opacity-50"
            >
              {capturing ? "Capture…" : "Copier l’interface"}
            </button>
            {captureStatus && <span className="text-[11px] text-slate-400">{captureStatus}</span>}
          </div>
        </div>

        <div className="grid items-start gap-4 xl:grid-cols-[minmax(0,1fr)_370px] 2xl:grid-cols-[minmax(0,1fr)_420px]">
          <div className="min-w-0 space-y-4">
            <section
              id="market-chart"
              className="scroll-mt-24 overflow-hidden rounded-xl border border-[#24334d] bg-[#0c1729] shadow-[0_8px_30px_rgba(0,0,0,.13)]"
            >
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#24334d] px-4 py-4">
                <div>
                  <h2 className="text-lg font-semibold">
                    BTCUSDC{" "}
                    <span className="ml-2 rounded-md border border-blue-500/25 bg-blue-500/10 px-2 py-1 align-middle text-[10px] font-medium text-blue-300">
                      {dataset.toUpperCase()}
                    </span>
                  </h2>
                  <p className="mt-1 text-[11px] text-slate-500">Market Explorer · Données Binance historiques</p>
                </div>
                <div className="flex flex-wrap gap-2 text-[11px]">
                  <span className="rounded-md border border-[#2a3c56] px-3 py-2 text-slate-300">
                    {candles.length} bougies
                  </span>
                  <span className="rounded-md border border-[#2a3c56] px-3 py-2 text-slate-300">
                    {signals.length} lignes d’évaluation
                  </span>
                </div>
              </div>
              <div className="border-b border-[#24334d] px-4 py-3">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex flex-wrap items-center gap-4 text-xs">
                    <span className="font-semibold text-slate-200">Signal Explorer</span>
                    {(
                      [
                        ["qwen", "Qwen V2"],
                        ["heuristic", "Heuristique"],
                        ["target", "Target (futur)"],
                      ] as const
                    ).map(([key, label]) => (
                      <label key={key} className="flex cursor-pointer items-center gap-1.5 text-[11px] text-slate-300">
                        <input
                          type="checkbox"
                          checked={signalSettings[key]}
                          onChange={(event) =>
                            setSignalSettings((current) => ({ ...current, [key]: event.target.checked }))
                          }
                          className="accent-blue-500"
                        />
                        {label}
                      </label>
                    ))}
                  </div>
                  <span className="text-[11px] text-slate-500">
                    Les targets sont uniquement des références a posteriori
                  </span>
                </div>
                <div className="mt-3 flex flex-wrap items-center gap-2">
                  {(
                    [
                      ["all", "Tous"],
                      ["win", "Gagnants (TP)"],
                      ["loss", "Perdants (SL)"],
                      ["disagree", "Désaccords"],
                    ] as [SignalFilter, string][]
                  ).map(([id, label]) => (
                    <FilterButton
                      key={id}
                      active={signalSettings.filter === id}
                      onClick={() => setSignalSettings((current) => ({ ...current, filter: id }))}
                    >
                      {label}
                    </FilterButton>
                  ))}
                  <span className="ml-auto text-[11px] text-slate-500">▲ LONG · ▼ SHORT</span>
                </div>
              </div>
              <div className="px-4 pt-3">
                <div className="flex flex-wrap gap-2 text-[11px]">
                  <span className="rounded-md border border-slate-700 px-3 py-1.5">
                    Signaux <b className="ml-1">{signalCounts.total}</b>
                  </span>
                  <span className="rounded-md border border-emerald-500/30 bg-emerald-500/5 px-3 py-1.5 text-emerald-300">
                    ▲ LONG {signalCounts.long}
                  </span>
                  <span className="rounded-md border border-rose-500/30 bg-rose-500/5 px-3 py-1.5 text-rose-300">
                    ▼ SHORT {signalCounts.short}
                  </span>
                  <span className="rounded-md border border-emerald-500/20 px-3 py-1.5 text-emerald-300">
                    TP {signalCounts.tp}
                  </span>
                  <span className="rounded-md border border-rose-500/20 px-3 py-1.5 text-rose-300">
                    SL {signalCounts.sl}
                  </span>
                  {signalCounts.other > 0 && (
                    <span className="rounded-md border border-slate-700 px-3 py-1.5 text-slate-400">
                      Autres {signalCounts.other}
                    </span>
                  )}
                </div>
              </div>
              {signalError && (
                <p className="mx-4 mt-3 rounded-md border border-rose-500/30 bg-rose-500/5 p-3 text-xs text-rose-300">
                  {signalError}
                </p>
              )}
              {focusedTime !== null && (
                <div className="mx-4 mt-3 flex flex-wrap items-center justify-between gap-2 rounded-md border border-amber-500/25 bg-amber-500/5 p-3 text-xs text-amber-300">
                  <span>
                    Exploration d’un désaccord historique ·{" "}
                    {new Date(focusedTime * 1000).toISOString().slice(0, 16).replace("T", " ")} UTC
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      setFocusedTime(null);
                      setSelectedTime(null);
                      setDetail(null);
                      setPrediction(null);
                    }}
                    className="rounded-md border border-amber-500/40 px-3 py-1.5 transition hover:bg-amber-500/10"
                  >
                    Retour aux 500 dernières bougies
                  </button>
                </div>
              )}
              {loading ? (
                <p className="px-5 py-24 text-center text-sm text-slate-400">Chargement du graphique…</p>
              ) : error ? (
                <p className="p-6 text-sm text-red-400">{error}</p>
              ) : candles.length === 0 ? (
                <p className="p-8 text-sm text-slate-400">Aucune bougie disponible pour cette période.</p>
              ) : (
                <div className="px-3 py-3">
                  <TradingChart
                    key={`${dataset}-${focusedTime ?? "latest"}`}
                    candles={candles}
                    signals={signals}
                    signalSettings={signalSettings}
                    selectedTime={selectedTime}
                    onSelectCandle={setSelectedTime}
                  />
                </div>
              )}
              <div className="border-t border-[#24334d] px-4 py-3 text-[11px] text-slate-500">
                Source : FastAPI / Parquet · Analyse historique, pas de trading en direct
              </div>
            </section>
          </div>
          <div className="min-w-0 space-y-4">
            <AIInspector
              dataset={dataset}
              selectedTime={selectedTime}
              detail={prediction}
              loading={predictionLoading}
              error={predictionError}
            />
            <CandleInspector detail={detail} loading={detailLoading} error={detailError} />
          </div>
        </div>
        <div id="analytics" className="scroll-mt-24">
          <PerformanceAnalytics dataset={dataset} />
        </div>
        <div id="disagreements" className="scroll-mt-24">
          <DisagreementExplorer dataset={dataset} selectedTime={selectedTime} onSelect={navigateToDisagreement} />
        </div>
        <footer className="pb-3 text-center text-[11px] text-slate-600">
          Qwen Trading Research · Graphiques par{" "}
          <a
            href="https://www.tradingview.com/"
            target="_blank"
            rel="noopener noreferrer"
            className="underline hover:text-slate-400"
          >
            TradingView
          </a>
        </footer>
      </div>
    </main>
  );
}
